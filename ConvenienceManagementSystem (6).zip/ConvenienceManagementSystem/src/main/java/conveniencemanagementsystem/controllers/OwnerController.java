package conveniencemanagementsystem.controllers;
import java.io.UnsupportedEncodingException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import conveniencemanagementsystem.models.UserBean;
import conveniencemanagementsystem.persistant.dao.CategoryDAO;
import conveniencemanagementsystem.persistant.dao.UserDAO;
import conveniencemanagementsystem.persistant.dto.UserResponseDTO;

@Controller	
public class OwnerController {	
    @SuppressWarnings("unused")	
	@Autowired
    private UserDAO userDAO;
    @Autowired
    private UserDAO salerdao;
    
    private final CategoryDAO categoryDAO;
	
	public OwnerController(
	  CategoryDAO categoryDAO		
	) {
		this.categoryDAO = categoryDAO;
	}
    
	 @GetMapping("/manageSaleStaff")
	    public String userRegister(Model model) {
	        model.addAttribute("userBean", new UserBean());
	        return "manageSaleStaff";
	    }
	 	
	 @GetMapping("/saleStaffRegister")
	    public ModelAndView salerRegister(Model model) {
		 return new ModelAndView("saleStaffRegister","user",new UserBean());
	       	
	        
	        
	    }
		/*
		 * @PostMapping("/saleStaffRegister") public String
		 * userRegister(@ModelAttribute("SaleStaffBean") @Validated SaleStaffBean
		 * saleStaffBean, BindingResult br, Model model) { if (br.hasErrors()) { return
		 * "registration"; } else if
		 * (!saleStaffBean.getPassword().equals(saleStaffBean.getPassword())) {
		 * model.addAttribute("passwordError", "Password doesn't match!"); return
		 * "registration"; } else if (UserHelper.isEmailExist(saleStaffBean.getEmail()))
		 * { model.addAttribute("error", "Email already exists."); return
		 * "registration"; } else { UserRequestDTO dto = new UserRequestDTO(); // Set
		 * dto properties from userBean dao.insertUser(dto);
		 * model.addAttribute("success", "Successfully registered."); return
		 * "redirect:/viewsaleStaffInformation"; } }
		 */
	 
	 
	 
	 @GetMapping("/viewSaleStaffInformation")
	    public String viewSaleStaffInformation(Model model) throws UnsupportedEncodingException {
	        model.addAttribute("userBean", new UserBean());
	        List<UserResponseDTO> staff=salerdao.getAllUser();
	        model.addAttribute("staff",staff);
	        
	        return "viewSaleStaffInformation";
	    }
}
