package conveniencemanagementsystem.controllers;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import conveniencemanagementsystem.models.UserBean;
import conveniencemanagementsystem.persistant.dao.CategoryDAO;
import conveniencemanagementsystem.persistant.dao.UserDAO;
import conveniencemanagementsystem.persistant.dto.UserRequestDTO;
import conveniencemanagementsystem.persistant.dto.UserResponseDTO;

@Controller 
public class PageController { 
	
	private final CategoryDAO categoryDAO;
	
	public PageController(
	  CategoryDAO categoryDAO		
	) {
		this.categoryDAO = categoryDAO;
	}
	
    @GetMapping("/") 
    public ModelAndView displayLogin() { 
        return new ModelAndView("login","user",new UserBean()); 
    } 
    
    @PostMapping("/login") 	
	public String login(@ModelAttribute("user") UserBean user, HttpSession session,ModelMap model) {
	   UserRequestDTO dto=new UserRequestDTO();  
	   dto.setEmail(user.getEmail());  
	   dto.setPassword(user.getPassword()); 
	   UserResponseDTO res = UserDAO.selectAllUser(dto);  
	   if( res.getPassword().equals(user.getPassword())){ 
		if(res.getRoles_id()==1){ 
		  return "redirect:owner";
		}
		
		if(res.getRoles_id()==2) {
			model.addAttribute("error","Login Success!!!");
			return "staff"; 
			
		}
		
	   }
	   model.addAttribute("error","Login Failed!!!"); 
	    return "login"; 
	} 
    
    @GetMapping("/logout") 
    public String Logout(RedirectAttributes redirect ){ 
      redirect.addFlashAttribute("success","Logout Successfully!");//Add in message 
        return "redirect:/";  
    } 
    
    @GetMapping("/owner") 
    public String Owner(ModelMap model){ 
    	model.addAttribute("categoryCount",categoryDAO.getCategoriesCount()); 
        return "owner";  
    } 
}