package conveniencemanagementsystem.persistant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import conveniencemanagementsystem.persistant.dto.DiscountRequestDTO;
import conveniencemanagementsystem.persistant.dto.DiscountResponseDTO;


public class DiscountDAO {
	public static Connection con=null;
	static {
		con=MyConnection.getConnection();
	}
	
	//insert
	public int addDiscount(DiscountRequestDTO discountDTO) {
		int result=0;
		System.out.println(discountDTO.getProducts_id());
		String sql="INSERT INTO discounts(name,products_id,discount_percent,from_date,to_date) VALUES(?,?,?,?,?)";
		try {
			
			PreparedStatement ps=con.prepareStatement(sql);
			
			ps.setString(1, discountDTO.getName());
			ps.setInt(2, discountDTO.getProducts_id());
			ps.setInt(3, discountDTO.getDiscount_percent());
			ps.setString(4, discountDTO.getFrom_date());
			ps.setString(5, discountDTO.getTo_date());
			
			result=ps.executeUpdate();
			
		}catch(SQLException e) {
			
			System.out.println("Insert error: "+e);
		}		
		return result;
	}
	
	//update
	public int editDiscount(DiscountRequestDTO discountDTO) {
		int result=0;
		System.out.println(discountDTO.getProducts_id());
		String sql="UPDATE discounts SET name=?,products_id=?,discount_percent=?,from_date=?,to_date=? WHERE id=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			
			ps.setString(1, discountDTO.getName());
			ps.setInt(2, discountDTO.getProducts_id());
			ps.setInt(3, discountDTO.getDiscount_percent());
			ps.setString(4, discountDTO.getFrom_date());
			ps.setString(5, discountDTO.getTo_date());
			
			ps.setInt(6, discountDTO.getId());
			
			result=ps.executeUpdate();			
		}catch(SQLException e) {
			System.out.println("Update error: "+e);
		}		
		return result;
	}
	
	//delete
	public int deleteDiscount(int id) {
		int result=0;
		String sql="DELETE FROM discounts WHERE id=?";
		try {
			
			PreparedStatement ps=con.prepareStatement(sql);
			
			ps.setInt(1, id);
			
			result=ps.executeUpdate();			
		}catch(SQLException e) {
			System.out.println("Delete error: "+e);
		}		
		return result;
	}

	//selectByCode
	public DiscountResponseDTO getDiscountById(int id) {
		DiscountResponseDTO discount=new DiscountResponseDTO();
		String sql="SELECT * FROM discounts WHERE id=?";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				
				discount.setId(rs.getInt("id"));
				discount.setName(rs.getString("name"));
				discount.setProducts_id(rs.getInt("products_id"));
				discount.setDiscount_percent(rs.getInt("discount_percent"));				
				discount.setFrom_date(rs.getString("from_date"));
				discount.setTo_date(rs.getString("to_date"));
				
			}				
		}catch(SQLException e) {
			System.out.println("select by code error"+e);
		}
		return discount;
	}
	
	//selectAll
	public List<DiscountResponseDTO> getAllDiscounts() {
		List<DiscountResponseDTO> discounts=new ArrayList<DiscountResponseDTO>();
		String sql="SELECT * FROM discounts";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);			
			ResultSet rs=ps.executeQuery();			
			while(rs.next()) {
				DiscountResponseDTO discount=new DiscountResponseDTO();
				discount.setId(rs.getInt("id"));
				discount.setName(rs.getString("name"));
				discount.setProducts_id(rs.getInt("products_id"));
				discount.setDiscount_percent(rs.getInt("discount_percent"));				
				discount.setFrom_date(rs.getString("from_date"));
				discount.setTo_date(rs.getString("to_date"));
				
				discounts.add(discount);
			}				
		}catch(SQLException e) {
			System.out.println("select all error: "+e);
		}
		return discounts;
	}
}
