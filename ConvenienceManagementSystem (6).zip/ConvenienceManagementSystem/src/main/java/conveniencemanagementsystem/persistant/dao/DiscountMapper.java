package conveniencemanagementsystem.persistant.dao;

import java.util.ArrayList;
import java.util.List;

import conveniencemanagementsystem.models.DiscountBean;
import conveniencemanagementsystem.persistant.dto.DiscountRequestDTO;
import conveniencemanagementsystem.persistant.dto.DiscountResponseDTO;


public class DiscountMapper {
	
	public DiscountRequestDTO mapToRequestDTO(DiscountBean bean) {
		DiscountRequestDTO dto=new DiscountRequestDTO();
		dto.setId(bean.getId());
		dto.setName(bean.getName());
		dto.setProducts_id(bean.getProducts_id());
		dto.setDiscount_percent(bean.getDiscount_percent());
		dto.setFrom_date(bean.getFrom_date());
		dto.setTo_date(bean.getTo_date());
		
		return dto;
	}
	
	public DiscountBean mapToBean(DiscountResponseDTO dto) {
		ProductDAO productDAO=new ProductDAO();
		
		DiscountBean bean=new DiscountBean();
		bean.setId(dto.getId());
		bean.setName(dto.getName());
		bean.setProducts_id(dto.getProducts_id());
		
		String product_name=productDAO.getProductNameById(dto.getProducts_id());
		bean.setProduct_name(product_name);
		bean.setDiscount_percent(dto.getDiscount_percent());
		bean.setFrom_date(dto.getFrom_date());
		bean.setTo_date(dto.getTo_date());
		return bean;
	}
	public List<DiscountBean> mapToListBean(List<DiscountResponseDTO> dtos) {
		List<DiscountBean> beans=new ArrayList<DiscountBean>();
		for(DiscountResponseDTO dto:dtos) {
			DiscountBean bean=mapToBean(dto);
			
			beans.add(bean);
		}
		return beans;
	}
}
