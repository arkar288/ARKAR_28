package conveniencemanagementsystem.persistant.dao;

import java.io.UnsupportedEncodingException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.tomcat.util.codec.binary.Base64;

import conveniencemanagementsystem.persistant.dto.ProductRequestDTO;
import conveniencemanagementsystem.persistant.dto.ProductResponseDTO;



public class ProductDAO {
	public static Connection con=null;
	static {
		con=MyConnection.getConnection();
	}
	
	//insert
	public int addProduct(ProductRequestDTO productDTO) {
		int result=0;
		System.out.println(productDTO.getProducts_categories_id());
		String sql="INSERT INTO products(name,product_code,products_categories_id,original_price,sold_price,product_qty,product_image,product_detail) VALUES(?,?,?,?,?,?,?,?)";
		try {
			
			PreparedStatement ps=con.prepareStatement(sql);
			
			ps.setString(1, productDTO.getName());
			ps.setString(2, productDTO.getProduct_code());
			ps.setInt(3, productDTO.getProducts_categories_id());
			ps.setDouble(4, productDTO.getOriginal_price());
			ps.setDouble(5, productDTO.getSold_price());
			ps.setInt(6, productDTO.getProduct_qty());
			ps.setBlob(7, productDTO.getImage_blob());
			ps.setString(8, productDTO.getProduct_detail());
			
			result=ps.executeUpdate();
			
		}catch(SQLException e) {
			
			System.out.println("Insert error: "+e);
		}		
		return result;
	}
	
	//update
	public int editProduct(ProductRequestDTO productDTO) {
		int result=0;
		System.out.println(productDTO.getProducts_categories_id());
		String sql="UPDATE products SET name=?,product_code=?,products_categories_id=?,original_price=?,sold_price=?,product_qty=?,product_image=?,product_detail=? WHERE id=?";
		
		try {
			
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, productDTO.getName());
			ps.setString(2, productDTO.getProduct_code());
			ps.setInt(3, productDTO.getProducts_categories_id());
			ps.setDouble(4, productDTO.getOriginal_price());
			ps.setDouble(5, productDTO.getSold_price());
			ps.setInt(6, productDTO.getProduct_qty());
			ps.setBlob(7, productDTO.getImage_blob());
			ps.setString(8, productDTO.getProduct_detail());
			ps.setInt(9, productDTO.getId());
			
			result=ps.executeUpdate();

		}catch(SQLException e) {
			System.out.println("Update error: "+e);
			e.printStackTrace();
		}		
		return result;
	}
	
	//delete
	public int deleteProduct(int id) {
		int result=0;
		String sql="DELETE FROM products WHERE id=?";
		try {
			
			PreparedStatement ps=con.prepareStatement(sql);
			
			ps.setInt(1, id);
			
			result=ps.executeUpdate();			
		}catch(SQLException e) {
			System.out.println("Delete error: "+e);
		}		
		return result;
	}

	//selectByCode
	public ProductResponseDTO getProductById(int id) {
	ProductResponseDTO product=new ProductResponseDTO();
		String sql="SELECT * FROM products WHERE id=?";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				product.setId(rs.getInt("id"));
				product.setName(rs.getString("name"));
				product.setProduct_code(rs.getString("product_code"));
				product.setProducts_categories_id(rs.getInt("products_categories_id"));				
				product.setOriginal_price(rs.getDouble("original_price"));
				product.setSold_price(rs.getDouble("sold_price"));
				product.setProduct_qty(rs.getInt("product_qty"));
				product.setProduct_detail(rs.getString("product_detail"));
				
			}				
		}catch(SQLException e) {
			System.out.println("select by code error"+e);
		}
		return product;
	}
	
	public String getProductNameById(int id) {
		String name="";
		String sql = "SELECT name FROM products WHERE id=?";
		try {
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {					
				name=rs.getString("name");					
			}
		} catch (SQLException e) {
			
			System.out.println("select product by id error" + e);
		}
		
		return name;
	}
	
	//selectAll
	public List<ProductResponseDTO> getAllProducts() throws UnsupportedEncodingException {
		List<ProductResponseDTO> products=new ArrayList<ProductResponseDTO>();
		String sql="SELECT * FROM products";
		
		try {
			PreparedStatement ps=con.prepareStatement(sql);			
			ResultSet rs=ps.executeQuery();			
			while(rs.next()) {
				ProductResponseDTO product=new ProductResponseDTO();
				product.setId(rs.getInt("id"));
				product.setName(rs.getString("name"));
				product.setProduct_code(rs.getString("product_code"));
				product.setProducts_categories_id(rs.getInt("products_categories_id"));				
				product.setOriginal_price(rs.getDouble("original_price"));
				product.setSold_price(rs.getDouble("sold_price"));
				product.setProduct_qty(rs.getInt("product_qty"));
				Blob image_Blob = (Blob) rs.getBlob("product_image");
				byte[] bytes = image_Blob.getBytes(1, (int) image_Blob.length());
				byte[] encodeBase64 = Base64.encodeBase64(bytes);
				product.setProduct_image(new String(encodeBase64, "UTF-8"));
				product.setProduct_detail(rs.getString("product_detail"));
				
				products.add(product);
			}				
		}catch(SQLException e) {
			System.out.println("select all error: "+e);
		}
		return products;
	}
	
	public int getLastProductId() {
	    int lastProductId = 0;
	    String sql = "SELECT MAX(id) as productId FROM products";
	    
	    try {
	      
	      PreparedStatement ps=con.prepareStatement(sql);      
	      ResultSet rs=ps.executeQuery();  
	      
	      while(rs.next()) {
	        lastProductId = rs.getInt("productId"); 
	      }        
	    }catch(SQLException e) {
	      System.out.println("select Last Id error: "+e);
	    }
	    return lastProductId;
	}

	
}
